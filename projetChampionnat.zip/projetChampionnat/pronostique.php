<?php
    session_start();

    if(isset($_POST['match1']) && $_SESSION['statut'][0]){
    $_SESSION['scoreTete1AM1']=$_POST['scoreTete1AM1'];
    $_SESSION['scoreTete2AM1']=$_POST['scoreTete2AM1'];
    $_SESSION['statut'][0]=false;
    }

    if(isset($_POST['match2']) && $_SESSION['statut'][1]){
        $_SESSION['scoreTete3AM1']=$_POST['scoreTete3AM1'];
    $_SESSION['scoreTete4AM1']=$_POST['scoreTete4AM1'];
    $_SESSION['statut'][1]=false;
    }

    if(isset($_POST['match3']) && $_SESSION['statut'][2]){
        $_SESSION['scoreTete1AM2']=$_POST['scoreTete1AM2'];
    $_SESSION['scoreTete3AM2']=$_POST['scoreTete3AM2'];
    $_SESSION['statut'][2]=false;
    }


    if(isset($_POST['match4']) && $_SESSION['statut'][3]){
        $_SESSION['scoreTete2AM2']=$_POST['scoreTete2AM2'];
        $_SESSION['scoreTete4AM2']=$_POST['scoreTete4AM2'];
    $_SESSION['statut'][3]=false;
    }


    if(isset($_POST['match5']) && $_SESSION['statut'][4]){
        $_SESSION['scoreTete1AM2']=$_POST['scoreTete1AM2'];
        $_SESSION['scoreTete4AM2']=$_POST['scoreTete4AM2'];
    $_SESSION['statut'][4]=false;
    }
    if(isset($_POST['match6']) && $_SESSION['statut'][5]){
        $_SESSION['scoreTete2AM2']=$_POST['scoreTete2AM2'];
        $_SESSION['scoreTete4AM2']=$_POST['scoreTete4AM2'];
    $_SESSION['statut'][5]=false;
    }





?>
<!DOCTYPE html>
<html lang="en">

    <meta charset="UTF-8">
    <title>Document</title>

    <link rel="stylesheet" href="./pronostique.css/">

<body>

<h2>Les affiches du 1e tour</h2>
<table border="3">
<br><br>
    <tr>
    <th>Groupe A</th>
    <th>Affiche</th>
    <th>Score</th>
</tr>

<tr>
<td>Match 1</td>
<td><?=$_SESSION['tete1A']?> vs <?=$_SESSION['tete2A']?></td>
<td> 
<div class="tableau_match">
<form action="" method="post">
<?php if($_SESSION['statut'][0]) {?>  
    <input class="num" type="number" min="0" name="scoreTete1AM1">
     - 
    <input class="num" type="number" min="0" name="scoreTete2AM1">
    <input type="submit" value="valider" name="match1">
    <?php } else{ echo  $_SESSION['scoreTete1AM1']." VS ".$_SESSION['scoreTete2AM1']; } ?> 
</form>
</tr>

<tr>
<td>Match 2</td>
<td><?=$_SESSION['tete3A']?> vs <?=$_SESSION['tete4A']?></td>
<td>
<form action="" method="post"> 
<?php if($_SESSION['statut'][1]) {?>  
<input class="num" type="number" min="0" name="scoreTete3AM1" >
     - 
    <input class="num" type="number"min="0" name="scoreTete4AM1">
<input type="submit" value="valider" name="match2">
<?php } else{ echo  $_SESSION['scoreTete3AM1']." VS ".$_SESSION['scoreTete4AM1']; } ?> 
</tr>
<tr>

<td>Match 3</td>
<td><?=$_SESSION['tete1A']?> vs <?=$_SESSION['tete3A']?></td>
<td>
<form action="" method="POST">
<?php if($_SESSION['statut'][2]) {?> 
<input class="num" type="number"min="0" name="scoreTete1AM2">

<input class="num" type="number"min="0" name="scoreTete3AM2">

<input type="submit" value="valider" name="match3">
<?php } else{ echo  $_SESSION['scoreTete1AM2']." VS ".$_SESSION['scoreTete3AM2']; } ?>
</tr>

<td>Match 4</td>
<td><?=$_SESSION['tete2A']?> vs <?=$_SESSION['tete4A']?></td>
<td> 
<form action="" method="POST">
<?php if($_SESSION['statut'][3]) {?> 
<input class="num" type="number"min="0" name="scoreTete2AM2">

<input class="num" type="number"min="0" name="scoreTete4AM2">
<input type="submit" value="valider" name="match4">

<?php } else{ echo  $_SESSION['scoreTete2AM2']." VS ".$_SESSION['scoreTete4AM2']; } ?>
</tr>
</tr>
<tr>

<td>Match 5</td>

<td><?=$_SESSION['tete1A']?> vs <?=$_SESSION['tete4A']?></td>
<td> 
<form action="" method="POST">
<?php if($_SESSION['statut'][4]) {?> 

<input class="num" type="number" min="0" name="scoreTete1AM1">



<input class="num" type="number"min="0" name="scoreTete4A">



<input type="submit" value="valider" name="match5">
<?php } else{ echo  $_SESSION['scoreTete1AM2']." VS ".$_SESSION['scoreTete4AM2']; } ?>
</tr>
<tr>

<td>Match 6</td>
<td><?=$_SESSION['tete2A']?> vs <?=$_SESSION['tete3A']?></td>
<td>

<form action="" method="POST"> 
<?php if($_SESSION['statut'][5]) {?> 

<input class="num" type="number"min="0" name="scoreTete2AM2">



<input class="num" type="number" min="0" name="scoreTete3A">




<input type="submit" value="valider" name="match6">

<?php } else{ echo  $_SESSION['scoreTete2AM2']." VS ".$_SESSION['scoreTete3AM2']; } ?>
</table>

<!--Les affiches du GroupeB-->
    <table border="3">
<br><br>
<tr>
    <th>Groupe B</th>
    <th>Affiche</th>
    <th>Score</th>
</tr>
<tr>
<td>Match 7</td>
<td><?=$_SESSION['tete1B']?> vs <?=$_SESSION['tete2B']?></td>
<td>
<form action="" method="POST"> 
<input class="num" type="number"  min="0"name="scoreTete1B"
<?php if(isset($_POST['match7'])){ ?> value="<?php echo $_POST['scoreTete1B']?>" <?php  }?>>

<input class="num" type="number"min="0" name="scoreTete2B"
<?php if(isset($_POST['match7'])){ ?> value="<?php echo $_POST['scoreTete2B']?>" <?php  }?>>
<input type="submit" value="valider" name="match7">
</tr>
<tr>

<tr>
<td>Match 8</td>
<td><?=$_SESSION['tete3B']?> vs <?=$_SESSION['tete1B']?></td>
<td>
<form action="" method="POST">
<input class="num" type="number" name="scoreTete3B"
<?php if(isset($_POST['match8'])){ ?> value="<?php echo $_POST['scoreTete3B']?>" <?php  }?>>

<input class="num" type="number" name="scoreTete1B"
<?php if(isset($_POST['match8'])){ ?> value="<?php echo $_POST['scoreTete1B']?>" <?php  }?>>
<input type="submit" value="valider" name="match8">
</tr>
<tr>

<tr>
<td>Match 9</td>
<td><?=$_SESSION['tete1B']?> vs <?=$_SESSION['tete3A']?></td>
<td> 
<form action="" method="POST">
<input class="num" type="number" name="scoreTete1B"
<?php if(isset($_POST['match9'])){ ?> value="<?php echo $_POST['scoreTete1B']?>" <?php  }?>>

<input class="num" type="number" name="scoreTete3B"
<?php if(isset($_POST['match9'])){ ?> value="<?php echo $_POST['scoreTete3B']?>" <?php  }?>>
<input type="submit" value="valider" name="match9">
</tr>
<tr>

<tr>
<td>Match 10</td>
<td><?=$_SESSION['tete2B']?> vs <?=$_SESSION['tete4B']?></td>
<td> 
<form action="" method="POST">
<input class="num" type="number" name="scoreTete2B"
<?php if(isset($_POST['match10'])){ ?> value="<?php echo $_POST['scoreTete2B']?>" <?php  }?>> 

<input class="num" type="number" name="scoreTete4B"
<?php if(isset($_POST['match10'])){ ?> value="<?php echo $_POST['scoreTete4B']?>" <?php  }?>>
<input type="submit" value="valider" name="match10">
</tr>
<tr>

<tr>
<td>Match 11</td>
<td><?=$_SESSION['tete1B']?> vs <?=$_SESSION['tete2B']?></td>
<td> 
<form action="" method="POST">
<input class="num" type="number" name="scoreTete1B"
<?php if(isset($_POST['match11'])){ ?> value="<?php echo $_POST['scoreTete1B']?>" <?php  }?>>

<input class="num" type="number" name="scoreTete2B"
<?php if(isset($_POST['match11'])){ ?> value="<?php echo $_POST['scoreTete2B']?>" <?php  }?>>
<input type="submit" value="valider" name="match11">
</tr>
<tr>

<tr>
<td>Match 12</td>
<td><?=$_SESSION['tete1B']?> vs <?=$_SESSION['tete3B']?></td>
<td> 
<form action="" method="POST">
<input class="num" type="number" name="scoreTete1B"
<?php if(isset($_POST['match12'])){ ?> value="<?php echo $_POST['scoreTete1B']?>" <?php  }?>>

<input class="num" type="number" name="scoreTete3B"
<?php if(isset($_POST['match12'])){ ?> value="<?php echo $_POST['scoreTete3B']?>" <?php  }?>>
<input type="submit" value="valider" name="match12">
</tr>
<tr>
</table>






<!--Classement Groupe A du matchs du 1e tour-->
<table>
<h2>Classement du math</h2>
            <tr>
            <center>
      
                <table border="3">
                <br><br>
                <th bgcolor="gray" colspan='9'>Groupe A</th>
                </tr>
        
    </tr>
    <th></th>
    <th>MJ</th>
    <th>MG</th>
    <th>MN</th>
    <th>MP</th>
    <th>BP</th>
    <th>BC</th>
    <th>Dif</th>
    <th>Point</th>
    <tr>
    </tr>
    <td>Premier</td>
    <td>3</td>
    


    <td>2</td>
    <td>1</td>
    <td>0</td>
    <td>0</td>
    <td>3</td>
    <td>0</td>
    <td>7</td>
    </tr>
    <td>Deuxieme</td>
    <td>3</td>
    <td>2</td>
    <td>0</td>
    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>2</td>
    <td>6</td>
    <tr>
    </tr>
    <td>Troisieme</td>
    <td>3</td>
    <td>0</td>
    <td>3</td>
    <td>0</td>
    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>3</td>
    <tr>
    </tr>
    <td>Quatrieme</td>
    <td>3</td>
    <td>0</td>
    <td>0</td>
    <td>3</td>
    <td>4</td>
    <td>2</td>
    <td>2</td>
    <td>0</td>

    <!--Classement Groupe A du matchs du 1e tour-->
    <table>
            <tr>
            <center>
      
                <table border="3">
                <br><br>
                <th bgcolor="gray" colspan='9'>Groupe B</th>
                </tr>
        
    </tr>
    <th></th>
    <th>MJ</th>
    <th>MG</th>
    <th>MN</th>
    <th>MP</th>
    <th>BP</th>
    <th>BC</th>
    <th>Dif</th>
    <th>Point</th>
    <tr>
    </tr>
    <td>Premier</td>
    <td>3</td>
    <td>3</td>
    <td>0</td>
    <td>0</td>
    <td>2</td>
    <td>1</td>
    <td>2</td>
    <td>9</td>
    </tr>
    <td>Deuxieme</td>
    <td>3</td>
    <td>2</td>
    <td>0</td>
    <td>1</td>
    <td>2</td>
    <td>1</td>
    <td>2</td>
    <td>6</td>
    <tr>
    </tr>
    <td>Troisieme</td>
    <td>3</td>
    <td>1</td>
    <td>0</td>
    <td>2</td>
    <td>0</td>
    <td>1</td>
    <td>2</td>
    <td>1</td>
    <tr>
    </tr>
    <td>Quatrieme</td>
    <td>3</td>
    <td>0</td>
    <td>0</td>
    <td>4</td>
    <td>2</td>
    <td>3</td>
    <td>5</td>
    <td>0</td>
    




</body>
</html>