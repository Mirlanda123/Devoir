<?php
    session_start();
    $equipe=["Bresil","Argentine","France","Italie","Espagne","Allemagne","Portugal","Haiti"];
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./tire.css">

    <title></title>
</head>
<body>



    



<br><br><br><br><br><br><br><br><br><br><br><br>
<!--liste des tableau des equipes!-->
<table border="3">

          <h2>Tableau des Equipes</h2>
          <tr>
              <th bgcolor="gray"><p>Lot #1<br/>
              (1er tete de serie)
</p>
</th>
<th bgcolor="gray"><p>Lot #2<br/>
      (2e tete de serie)
</p>
</th>
<th bgcolor="gray"><p>Lot #3<br/>
        (3e tete de serie)
</p>
</th>

<th bgcolor="gray"><p>Lot #4<br/>
</p>
</th>
 </tr>
<tr>
<?php
 for($i=0;$i<8;$i++){
     if($i%2==0){
     ?>
    <td><?=$equipe[$i]?></td>

 <?php } }?>
</tr>
<?php
 for($i=0;$i<8;$i++){
     if($i%2==1){
     ?>
    <td><?=$equipe[$i]?></td>

 <?php } }?>
</tr>


<table>

<br>
<br>

<br>

<br>
<br>



<?php 
    if(isset($_SESSION['state'])){
?>

<h2>tableau du Tirage</h2>
            <tr>
                <th bgcolor="gray"></th>
                <th bgcolor="gray">Groupe A</th>
                <th bgcolor="gray">Groupe B</th>
</tr>

<tr>
    <td>1er tete de serie(TDS)</td>
    <td width="150"px><?php echo($_SESSION['tete1A']);?></td>
    <td width="150px"><?php echo($_SESSION['tete1B']);?></td>
</tr>
<tr>
    <td>2e tete de serie(TDS)</td>
    <td width="150px"><?php echo($_SESSION['tete2A']);?></td>
    <td width="150px"><?php echo($_SESSION['tete2B']);?></td>
</tr>
<tr>
<td>3e tete de serie(TDS)</td>
    <td width="150px"><?php echo($_SESSION['tete3A']);?></td>
    <td width="150px"><?php echo($_SESSION['tete3B']);?></td>
</tr>
<tr>
    <td>4e tete de serie(TDS)</td>
    <td width="150px"><?php echo($_SESSION['tete4A']);?></td>
    <td width="150px"><?php echo($_SESSION['tete4B']);?></td>
</tr>

</table>

<button class ="bouton_tirage"><a href="./traitement.php">Tirage</a></button>
    <?php } 
    $_SESSION['statut']=[true,true,true,true,true,true,true,true];
    $_SESSION['scoreTete1AM1']=0;
    $_SESSION['scoreTete2AM1']=0;

    $_SESSION['scoreTete3AM1']=0;
    $_SESSION['scoreTete4AM1']=0;

    $_SESSION['scoreTete1AM2']=0;
    $_SESSION['scoreTete3AM2']=0;

    $_SESSION['scoreTete2AM2']=0;
    $_SESSION['scoreTete4AM2']=0;
    
    $_SESSION['scoreTete1AM2']=0;
    $_SESSION['scoreTete4AM2']=0;
    
    $_SESSION['scoreTete2AM2']=0;
    $_SESSION['scoreTete3AM2']=0;
    
    $_SESSION['scoreTete1BM1']=0;
    $_SESSION['scoreTete2ABM2']=0;
    


    
    ?>
<div class ="contenu_pronostique">
    <a href="pronostique.php">Pronostique</a>

    </div>


    <br><br><br><br>
    <br><br><br><br>
    <br><br><br><br>
    <br><br><br><br>
    <footer>

    <div class="copyright">
     <p>copyright 2021 <a href="#">championnat</a> Infos. Tous droits reservé</p>
 </div>

</body>
</html>