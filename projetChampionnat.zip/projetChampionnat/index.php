
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel = "preconnect" href = "https://fonts.gstatic.com">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <title>Football</title>
    
</head>
<body>
    



<section class="banniere" id="banniere">
    <div class="contenu">
        <h2>Amusons nous avec le football</h2>

        <p>Sport opposant deux équipes de onze joueurs, où il faut faire pénétrer un ballon rond dans les buts adverses sans utiliser les mains (au Canada, on dit soccer).
Jouer au foot.Football américain sport voisin du rugby, où les joueurs sont protégés par un lourd équipement (au Canada, on dit Football).</p>
        <a href="tirages au sort.php" class="btn1">Tirage</a>
       
    </div>
</section>
<section class="apropos" id="apropos">
    <div class="row">
        <div class="col50">
            <h2 class="titre-texte">Historicité du football</h2>
            <p>Le football, tel que nous le connaissons, est né vers 
                la fin du XIXème siècle en Angleterre quand la
                 Football Association, toute première instance 
                 dirigeante de ce sport fut créée le 26 octobre 1863 
                 pour jouer avec un ballon qu’il était interdit de jouer 
                 avec ses mains, pas plus que l’adversaire. Ce jour-là les partisans 
                 du rugby et les adeptes du football décident de se séparer. 
                 (A noter que la vessie de caoutchouc remonte a 1862) 
                 Le 20 juillet 1885 était fondée la Football 
                 Association Cup réservé au professionnels. Né en 1855, le club de Sheffield passe pour le plus ancien de tous. En France c’est celui du Havre (1872), puis vient le Football Club de Paris (1879). La saison 1893-1894 voit se dérouler le premier championnat de France : le Standard Athletic Club en sort vainqueur...avec une équipe composé de 10 anglais et d’un Français. Le football est ensuite admis aux jeux Olympiques de 1900 à Paris. La coupe de France à quant a elle débuté en 1918 : Olympique (club parisien) bat F.C. Lyon par trois à zéro. La coupe du monde, créée par le Français Jules Rimet, remonte à 1930. Ouvrier chez Peugeot et footballeur amateur au club de Sochaux, Lucien Laurent a marqué le premier but de cette coupe à Montevideo (cocoricooo). L’exploit eut lieu le 13 juillet, à la 19ème minute du premier match que la France remportera sur le Mexique par 4 buts à 1. Coupe qui sera gagnée par l’Uruguay, en battant en finale l’Argentine 4 à 2.Le football, tel que nous le connaissons, est né vers la fin du XIXème siècle en Angleterre quand la Football Association, toute première instance dirigeante de ce sport fut créée le 26 octobre 1863 pour jouer avec un ballon qu’il était interdit de jouer avec ses mains, pas plus que l’adversaire. Ce jour-là les partisans du rugby et les adeptes du football décident de se séparer. (A noter que la vessie de caoutchouc remonte a 1862) Le 20 juillet 1885 était fondée la Football Association Cup réservé au professionnels. Né en 1855, le club de Sheffield passe pour le plus ancien de tous. En France c’est celui du Havre (1872), puis vient le Football Club de Paris (1879). La saison 1893-1894 voit se dérouler le premier championnat de France : le Standard Athletic Club en sort vainqueur...avec une équipe composé de 10 anglais et d’un Français. Le football est ensuite admis aux jeux Olympiques de 1900 à Paris. La coupe de France à quant a elle débuté en 1918 : Olympique (club parisien) bat F.C. Lyon par trois à zéro. La coupe du monde, créée par le Français Jules Rimet, remonte à 1930. Ouvrier chez Peugeot et footballeur amateur au club de Sochaux, Lucien Laurent a marqué le premier but de cette coupe à Montevideo (cocoricooo). L’exploit eut lieu le 13 juillet, à la 19ème minute du premier match que la France remportera sur le Mexique par 4 buts à 1. Coupe qui sera gagnée par l’Uruguay, en battant en finale l’Argentine 4 à 2.Le football, tel que nous le connaissons, est né vers la fin du XIXème siècle en Angleterre quand la Football Association, toute première instance dirigeante de ce sport fut créée le 26 octobre 1863 pour jouer avec un ballon qu’il était interdit de jouer avec ses mains, pas plus que l’adversaire. Ce jour-là les partisans du rugby et les adeptes du football décident de se séparer. (A noter que la vessie de caoutchouc remonte a 1862) Le 20 juillet 1885 était fondée la Football Association Cup réservé au professionnels. Né en 1855, le club de Sheffield passe pour le plus ancien de tous. En France c’est celui du Havre (1872), puis vient le Football Club de Paris (1879). La saison 1893-1894 voit se dérouler le premier championnat de France : le Standard Athletic Club en sort vainqueur...avec une équipe composé de 10 anglais et d’un Français. Le football est ensuite admis aux jeux Olympiques de 1900 à Paris. La coupe de France à quant a elle débuté en 1918 : Olympique (club parisien) bat F.C. Lyon par trois à zéro. La coupe du monde, créée par le Français Jules Rimet, remonte à 1930. Ouvrier chez Peugeot et footballeur amateur au club de Sochaux, Lucien Laurent a marqué le premier but de cette coupe à Montevideo (cocoricooo). L’exploit eut lieu le 13 juillet, à la 19ème minute du premier match que la France remportera sur le Mexique par 4 buts à 1. Coupe qui sera gagnée par l’Uruguay, 
                en battant en finale l’Argentine 4 à 2.
                <br><br><br>
                La Grande-Bretagne n’a peut-être pas été le lieu 
                de naissance du football, mais elle a été coup sûr son berceau et sa maison. Les cohortes romaines peuvent avoir planté la graine, mais le sol était bon, avec le tempérament de ces islanders faits pour la rude et vigoureuse dépense physique » Avant d’atteindre l’ère moderne avec sa forme actuelle, le football anglais connaît bien des aventures. Le terme football ne fait son apparition qu’en 1486 et les expressions ball play (jeu de balle) ou playing at ball (jouer au ballon) lui sont préférées.


            </p>
        </div>
        <div class="col50">
            <div class="img">
                <img src="./image/ldc-trophy.png" alt="gif">
            </div>
        </div>
    </div>
</section>
<section class="menu" id="menu">
    <div class="titre">
        <h2 class="titre-texte"><span>Les</span><br>équipes</h2>
      
    </div>
    <div class="contenu">
        <div class="box">
            <div class="imbox">
                <img src="./image/drapeau-bresil.jpg" alt="">
            </div>
            <div class="text">
                <h3>Brésil</h3>
            </div>
        </div>
        <div class="box">
            <div class="imbox">
                <img src="./image/drapeau-argentine.jpg" alt="">
            </div>
            <div class="text">
                <h3>Argentine</h3>
            </div>
        </div>
        <div class="box">
            <div class="imbox">
                <img src="./image/drapeau-allemagne.jpg" alt="">
            </div>
            <div class="text">
                <h3>Allemagne</h3>
            </div>
        </div>
        <div class="box">
            <div class="imbox">
                <img src="./image/drapeau-france.jpg" alt="">
            </div>
            <div class="text">
                <h3>France</h3>
            </div>
        </div>
        <div class="box">
            <div class="imbox">
                <img src="./image/drapeau-italie.jpg" alt="">
            </div>
            <div class="text">
                <h3>Italie</h3>
            </div>
        </div>
        <div class="box">
            <div class="imbox">
                <img src="./image/drapeau-espagne.jpg" alt="">
            </div>
            <div class="text">
                <h3>Espagne</h3>
            </div>
        </div>
        <div class="box">
            <div class="imbox">
                <img src="./image/drapeau-haiti.jpg" alt="">
            </div>
            <div class="text">
                <h3>Haiti</h3>
            </div>
        </div>
        <div class="box">
            <div class="imbox">
                <img src="./image/drapeau-portugal.jpg" alt="">
            </div>
            <div class="text">
                <h3>Portugal</h3>
            </div>
        </div>
    </div>
 </div>
 <div class="titre">
    <a href="#" class="btn1">Visionnons</a>
 </div>
</section>
<section class="expert" id="expert">
    <div class="titre">
        <h2 class="titre-texte">

    </div>
    <div class="contenu">
        <div class="box">
            <div class="imbox">
                <img src="./image/Messi.jpg" alt="">
            </div>
            <div class="text">
                <p>Lionel Messi, parfois surnommé Leo Messi, né le 24 juin 1987 à Rosario en Argentine,
                     est un footballeur international argentin évoluant au poste d'attaquant au Paris Saint-Germain.

Seul joueur six fois Ballon d'or et Soulier d'or, Messi est considéré comme l'un des 
meilleurs joueurs de football toutes générations confondues. Joueur le plus décisif du xxie siècle, 
meilleur buteur sous un seul maillot en club, il est élu meilleur ailier droit de tous les temps par France Football tandis
 que l'IFFHS le désigne
 meilleur joueur de la décennie de 2011 à 2020.
</p>
      
            </div>
        </div>
        <div class="box">
            <div class="imbox">
                <img src="./image/Christiano.jpg" alt="">
            </div>
            <div class="text">
                
            <p>
            Cristiano Ronaldo dos Santos Aveiro, couramment appelé Ronaldo ou Cristiano Ronaldo et surnommé CR7, né le 5 février 1985 à Funchal, est un footballeur international portugais qui évolue au poste d'attaquant à Manchester United.

Considéré comme l'un des meilleurs joueurs de l'histoire de son sport, il est le seul
 footballeur avec Lionel Messi à avoir remporté le Ballon d'or au moins cinq fois : en 2008, 
 2013, 2014, 2016 et en 2017. Auteur de plus de 780 buts en carrière, il est le meilleur buteur de 
 la Ligue des champions de l'UEFA, des coupes d'Europe, du Real Madrid, du derby madrilène, 
 de la Coupe du monde des clubs de la FIFA et de la sélection portugaise, dont il est 
 le capitaine depuis 2007. 
</p>     
            </div>
        </div>
        <div class="box">
            <div class="imbox">
                <img src="./image/junior Neymar.jpg" alt="">
            </div>
            <div class="text">
            <p>  
            Neymar da Silva Santos Júnior, dit Neymar Jr., plus couramment appelé Neymar, né le 5 février 1992 à Mogi das Cruzes (Brésil, État de São Paulo), est un footballeur international brésilien qui évolue au poste d'attaquant au Paris Saint-Germain. Il est également le capitaine de l'équipe nationale du Brésil depuis 2014.

Il est considéré comme l'un des plus grands joueur du football brésilien et mondial.
 Il est ainsi élu meilleur joueur sud-américain de l'année en 2011 et 2012. Neymar est classé dixième au classement du Ballon d'or 2011, treizième en 2012 puis cinquième en 2013 et en 2016. Il remporte par ailleurs le Bola de Ouro du meilleur joueur du championnat brésilien en 2011.

Neymar rejoint le club de Santos en 2003. Il évolue dans les équipes de jeunes jusqu'en 2009, 
date à laquelle il rejoint l'équipe fanion. Avec ce club, Neymar remporte la Coupe du Brésil, 
deux championnats de l'État de São Paulo, la Recopa Sudamericana et la Copa Libertadores. 

  </p>  
                
            </div>
        </div>
        <div class="box">
            <div class="imbox">
                <img src="./image/Sergio Ramos.jpg" alt="">
            </div>
            <div class="text">
            Sergio Ramos García, né le 30 mars 1986 à Camas en Andalousie, est un footballeur 
            international espagnol qui évolue au poste de défenseur central au Paris Saint-Germain.

Il effectue l'essentiel de sa carrière au Real Madrid et avec l'équipe d'Espagne au poste de
 défenseur central ou de latéral lors de ses débuts à Séville et à Madrid.

Sous le maillot de sa sélection nationale, il remporte l'Euro 2008, la Coupe du monde 2010
 et l'Euro 2012 en tant que titulaire, faisant donc partie des sept joueurs présents sur le
 terrain lors de ces trois finales remportées consécutivement pour une triple couronne inédite dans
  l'histoire du football mondial. Il est par ailleurs actuellement le joueur le plus capé de la sélection
   espagnole devant Iker Casillas.
            </div>
        </div>
    </div>
 </div>
</section>
 <section class="temoignage" id="temoignage">
    <div class="titre blanc">
        
    
            </div>
        </div>
    </div>
 </section>

 <div class="copyright">
     <p>copyright 2021 <a href="#">championnat</a> Infos. Tous droits reservé</p>
 </div>

 </div>



</body>
</html>