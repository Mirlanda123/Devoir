<?php
    // <?php
    session_start();
    $equipe=["Bresil","Argentine","France","Italie","Espagne","Allemagne","Portugal","Haiti"];
    // 
    // <!--  -->
    // tirage

$tete1A=rand(0,1);
$tete1B=rand(0,1);

while ($tete1A==$tete1B) {
    $tete1B=rand(0,1);
}

$tete2A=rand(2,3);
$tete2B=rand(2,3);
while ($tete2A==$tete2B) {
    $tete2B=rand(2,3);
}

$tete3A=rand(4,5);
$tete3B=rand(4,5);

while ($tete3A==$tete3B) {
    $tete3B=rand(4,5);
}

$tete4A=rand(6,7);
$tete4B=rand(6,7);

while ($tete4A==$tete4B) {
    $tete4B=rand(6,7);
}
$_SESSION['tete1A']=$equipe[$tete1A];
$_SESSION['tete1B']=$equipe[$tete1B];
$_SESSION['tete2A']=$equipe[$tete2A];
$_SESSION['tete2B']=$equipe[$tete2B];
$_SESSION['tete3A']=$equipe[$tete3A];
$_SESSION['tete3B']=$equipe[$tete3B];
$_SESSION['tete4A']=$equipe[$tete4A];
$_SESSION['tete4B']=$equipe[$tete4B];
$_SESSION['state'] = 0;

header('location:./tirages au sort.php');

?>
