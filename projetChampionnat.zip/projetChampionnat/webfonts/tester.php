<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<p>Hello!</p>

<p>Vous,vous appelez <?php echo
$_POST['prenom']; ?> !</p>
<p>Si tu veux changer de prénom, <a href="formulaire.php">clique
ici</a> pour revenir à formulaire.php</p>





<p>Hello!</p>

<p>Vous,vous appelez <?php echo
$_POST['nom']; ?> !</p>
<p>Si tu veux changer de prénom, <a href="formulaire.php">clique
ici</a> pour revenir à formulaire.php</p>
<p>Hello!</p>

<p>Vous,vous appelez <?php echo
$_POST['mot_de passe']; ?> !</p>
<p>Si tu veux changer de prénom, <a href="formulaire.php">clique
ici</a> pour revenir à formulaire.php</p>
<p>Hello!</p>
